# ToDo4ToDay by RTNA

Application Flutter Android de gestion quotidienne des tâches.

## Compilation
Le workflow GitHub Actions doit générer le dossier Android avant la compilation :
`flutter create . --platforms=android`

Puis :
`flutter pub get`
`flutter build apk --release`

Le code conserve les tâches localement avec SharedPreferences. Cette version initiale comprend l'ajout, la modification, la suppression, un chronomètre basé sur les horodatages, la validation de fin et un bilan.
